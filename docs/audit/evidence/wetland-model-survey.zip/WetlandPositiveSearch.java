import java.util.*;
import java.nio.file.*;
import java.io.*;
import com.google.gson.Gson;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.core.*;
import net.minecraft.core.registries.*;
import net.minecraft.data.registries.VanillaRegistries;
import net.minecraft.world.level.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.placement.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.util.RandomSource;

/** Read-only base-noise/biome calculation. Never creates a world or invokes any feature. */
public class WetlandPositiveSearch {
 static final long SEED=-7620530482425397421L;
 static final int MIN_X=-112,MAX_X=-80,MIN_Z=-64,MAX_Z=-32;
 static final int NATIVE_INDEX=103,STAGE=9,RADIUS=2;
 static final Gson GSON=new Gson();
 static ChunkGenerator gen; static RandomState randomState; static BiomeManager biomeManager; static LevelHeightAccessor heightAccess;
 static final Map<Long,NoiseColumn> columns=new HashMap<>(); static int nativeHeightChecks=0;
 record Sample(int x,int y,int z,String biome,String baseGround,boolean wetland,boolean groundProxy,boolean waterEvaluated,boolean waterAdjacent,List<String> waterAt,boolean baseOpenSky,boolean eligible) {}
 record Window(int cx,int cz,int score,int distanceSquared) {}
 static Map<String,Object> obj(Object... pairs){var m=new LinkedHashMap<String,Object>();for(int i=0;i<pairs.length;i+=2)m.put((String)pairs[i],pairs[i+1]);return m;}
 static long key(int x,int z){return ((long)x<<32)^(z&0xffffffffL);}
 static NoiseColumn column(int x,int z){return columns.computeIfAbsent(key(x,z),k->gen.getBaseColumn(x,z,heightAccess,randomState));}
 static int top(int x,int z){var c=column(x,z);for(int y=gen.getMinY()+gen.getGenDepth()-1;y>=gen.getMinY();y--)if(Heightmap.Types.WORLD_SURFACE_WG.isOpaque().test(c.getBlock(y)))return y+1;return gen.getMinY();}
 static boolean wetland(Holder<Biome> b){return b.is(Biomes.SWAMP)||b.is(Biomes.MANGROVE_SWAMP);}
 static Sample sample(int x,int z){
  int y=top(x,z);var b=biomeManager.getBiome(new BlockPos(x,y,z));var ground=column(x,z).getBlock(y-1);
  boolean land=!ground.isAir()&&ground.getFluidState().isEmpty(),wet=false;var waterAt=new ArrayList<String>();
  if(wetland(b)&&land)for(var d:Direction.Plane.HORIZONTAL){var nc=column(x+d.getStepX(),z+d.getStepZ());for(int dy=0;dy<=2;dy++)if(nc.getBlock(y-dy).getFluidState().is(net.minecraft.world.level.material.Fluids.WATER)){wet=true;waterAt.add((x+d.getStepX())+"/"+(y-dy)+"/"+(z+d.getStepZ()));}}
  boolean open=column(x,z).getBlock(y).isAir();
  return new Sample(x,y,z,b.unwrapKey().orElseThrow().identifier().toString(),BuiltInRegistries.BLOCK.getKey(ground.getBlock()).toString(),wetland(b),land,wetland(b)&&land,wet,List.copyOf(waterAt),open,wetland(b)&&land&&wet&&open);
 }
 static void emit(PrintWriter out,Object value){out.println(GSON.toJson(value));out.flush();}
 public static void main(String[] args)throws Exception{
  SharedConstants.tryDetectVersion();Bootstrap.bootStrap();var lookup=VanillaRegistries.createWorldLookup();
  gen=lookup.lookupOrThrow(Registries.WORLD_PRESET).getOrThrow(WorldPresets.NORMAL).value().overworld().orElseThrow().generator();
  randomState=RandomState.create(lookup.lookupOrThrow(Registries.NOISE),SEED,((NoiseBasedChunkGenerator)gen).generatorSettings().value());
  biomeManager=new BiomeManager(gen.getBiomeSource().createCachingResolver(randomState),BiomeManager.obfuscateSeed(SEED));
  heightAccess=LevelHeightAccessor.create(gen.getMinY(),gen.getGenDepth());
  try(var terrain=new PrintWriter(Files.newBufferedWriter(Path.of("terrain-samples.jsonl")))){
   int[][] scores=new int[MAX_X-MIN_X+1][MAX_Z-MIN_Z+1];int eligible=0,wetlandSamples=0;long start=System.nanoTime();
   for(int cx=MIN_X;cx<=MAX_X;cx++){
    for(int cz=MIN_Z;cz<=MAX_Z;cz++)for(int ox:new int[]{4,12})for(int oz:new int[]{4,12}){
     var s=sample(cx*16+ox,cz*16+oz);emit(terrain,s);if(s.eligible()){scores[cx-MIN_X][cz-MIN_Z]++;eligible++;}if(s.wetland())wetlandSamples++;
     if(nativeHeightChecks<10){int nativeY=gen.getBaseHeight(s.x(),s.z(),Heightmap.Types.WORLD_SURFACE_WG,heightAccess,randomState);if(nativeY!=s.y())throw new AssertionError("base column top mismatch");nativeHeightChecks++;}
    }
    System.out.println("TERRAIN_PROGRESS x="+cx+" eligible="+eligible+" columns="+columns.size()+" seconds="+((System.nanoTime()-start)/1e9));
   }
   var windows=new ArrayList<Window>();
   for(int cx=MIN_X+RADIUS;cx<=MAX_X-RADIUS;cx++)for(int cz=MIN_Z+RADIUS;cz<=MAX_Z-RADIUS;cz++){
    int score=0;for(int dx=-RADIUS;dx<=RADIUS;dx++)for(int dz=-RADIUS;dz<=RADIUS;dz++)score+=scores[cx+dx-MIN_X][cz+dz-MIN_Z];
    windows.add(new Window(cx,cz,score,(cx+96)*(cx+96)+(cz+48)*(cz+48)));
   }
   windows.sort(Comparator.comparingInt(Window::score).reversed().thenComparingInt(Window::distanceSquared).thenComparingInt(Window::cx).thenComparingInt(Window::cz));
   try(var w=new PrintWriter(Files.newBufferedWriter(Path.of("all-window-scores.jsonl")))){for(var row:windows)emit(w,row);}
   var chosen=windows.getFirst();
   var selection=obj("seed",Long.toString(SEED),"chosenByTerrainOnly",true,"centerChunk",List.of(chosen.cx(),chosen.cz()),"chunkX",List.of(chosen.cx()-RADIUS,chosen.cx()+RADIUS),"chunkZ",List.of(chosen.cz()-RADIUS,chosen.cz()+RADIUS),"eligibleSamples",chosen.score(),"samplesPerWindow",100,"totalSamples",4356,"totalWetlandSamples",wetlandSamples,"totalEligibleSamples",eligible,"nativeHeightCrossChecks",nativeHeightChecks,"modelOnly",true);
   Files.writeString(Path.of("terrain-selection.json"),GSON.toJson(selection)+"\n");System.out.println("TERRAIN_SELECTION "+GSON.toJson(selection));
   // Terrain selection is complete and persisted before the first Moonreed RNG draw.
   try(var attempts=new PrintWriter(Files.newBufferedWriter(Path.of("all-random-outcomes.jsonl")))){
    int passes=0,admitted=0,allWetDraws=0,selectedSources=0,selectedWetDraws=0;
    for(int cx=MIN_X;cx<=MAX_X;cx++)for(int cz=MIN_Z;cz<=MAX_Z;cz++){
     var r=new WorldgenRandom(new XoroshiroRandomSource(0));long decorationSeed=r.setDecorationSeed(SEED,cx*16,cz*16);r.setFeatureSeed(decorationSeed,NATIVE_INDEX,STAGE);
     boolean rarity=RarityFilter.onAverageOnceEvery(6).shouldPlace(null,r,BlockPos.ZERO),selected=Math.abs(cx-chosen.cx())<=RADIUS&&Math.abs(cz-chosen.cz())<=RADIUS;
     if(!rarity){emit(attempts,obj("chunk",List.of(cx,cz),"rarityPass",false,"selectedWindow",selected));continue;}
     passes++;var origin=new BlockPos[1];InSquarePlacement.spread().modify(null,r,new BlockPos(cx*16,0,cz*16),p->origin[0]=p);
     var os=sample(origin[0].getX(),origin[0].getZ());boolean allows=os.wetland();if(allows)admitted++;var draws=new ArrayList<Object>();int wetDraws=0;
     for(int n=0;n<24;n++){int x=origin[0].getX()+r.nextInt(9)-4,z=origin[0].getZ()+r.nextInt(9)-4;
      if(allows){var s=sample(x,z);if(s.groundProxy()&&s.waterAdjacent()&&s.baseOpenSky())wetDraws++;draws.add(obj("attempt",n+1,"sample",s));}
      else draws.add(obj("attempt",n+1,"x",x,"z",z,"terrainNotEvaluatedBecauseOriginBiomeRefuses",true));
     }
     allWetDraws+=wetDraws;if(selected&&allows){selectedSources++;selectedWetDraws+=wetDraws;}
     var result=obj("chunk",List.of(cx,cz),"rarityPass",true,"selectedWindow",selected,"origin",os,"originBiomeAllows",allows,"wetGroundProxyDraws",wetDraws,"attempts",draws);
     emit(attempts,result);if(selected||wetDraws>0)System.out.println("CANDIDATE "+GSON.toJson(result));
    }
    var summary=obj("sourceChunks",1089,"rarityPass",passes,"wetlandOriginCalls",admitted,"allWetGroundProxyDraws",allWetDraws,"selectedWindowWetlandCalls",selectedSources,"selectedWindowWetGroundProxyDraws",selectedWetDraws,"evaluatedColumns",columns.size(),"modelOnly",true);
    Files.writeString(Path.of("model-summary.json"),GSON.toJson(summary)+"\n");System.out.println("SUMMARY "+GSON.toJson(summary));
   }
  }
 }
}
