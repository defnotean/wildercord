# Bounded native-library Moonreed candidate survey

This directory contains a completed, read-only survey for source commit `b3ec979da3640afd99755e2f2bcab1c2e5fbd410`, seed `-7620530482425397421`. It never launches Minecraft, places a feature, or edits repository files. **None of the new sites is native-world proven.** Native discovery must confirm actual substrate, empty space, water, writes, and persistence.

## Recommended native discovery target

Use the fixed 3×3 chunk square **X -110..-108, Z -51..-49**, centered on source chunk **(-109,-50)**. Its modeled placement origin is **(-1737,63,-786)** in swamp. The native-observed stage is 9 and feature index is 103.

Three unique bank coordinates receive four production RNG draws:

| Attempt | Candidate | Interpretation |
| --- | --- | --- |
| 9 | (-1738,63,-789) | Base solid bank with adjacent water |
| 13 | (-1740,63,-786) | Base solid bank with adjacent water |
| 23 | (-1738,63,-789) | Duplicate attempt 9, not a fourth independent site |
| 24 | (-1739,63,-786) | Base solid bank with adjacent water |

The origin itself is over water; that is allowed by the placed feature. Each local attempt evaluates its own top and bank. A successful attempt 9 would make attempt 23 fail the empty check; do not expect four writes. The base substrate is stone because surface building is not performed by `getBaseColumn`. It is only a land proxy, **not** proof of the actual `moonreed_ground` tag. The candidate heights/biomes/water coordinates are in `native-discovery-candidates.json`.

This is a **targeted representative integration candidate**, not a preregistered unbiased distribution window. It was selected **after** the terrain-only 5×5 winner had zero qualifying draws and the fixed model corpus was evaluated, from all four model-positive source chunks, because it has the largest number of distinct candidate bank coordinates (three). It is a candidate for a named deterministic integration fixture. It is **not** the preregistered terrain-only winning window and must not be described as such. No new region was added after inspecting outcomes. The original failed native case remains independently retained.

## Fixed sampling plan and the negative result

`preregistered-plan.json` was written before the first survey run. Its SHA256 is recorded in `source-manifest.json`. It defines:

- One seed; 33×33 source chunks, X -112..-80 and Z -64..-32, centered on the original chunk (-96,-48).
- Four terrain samples per chunk, at local X/Z offsets 4 and 12: exactly 4,356 samples.
- Habitat proxy: swamp or mangrove swamp surface biome; exposed non-fluid solid base surface; horizontal base water at the candidate Y, Y-1, or Y-2; base open sky.
- A 5×5 window ranking by eligible terrain sample count, then squared distance from the original center, then center X and Z. There are exactly 841 eligible windows.
- Terrain selection is persisted before any Moonreed RNG is evaluated.
- Every source chunk gets one native rarity calculation at the already observed index 103; all passing source origins and all 24 local coordinate draws are retained. Non-wetland origins have coordinates reported but no terrain evaluation for their unused draws.

The terrain-only winning window is centered at **(-108,-41)**: X -110..-106, Z -43..-39. It has 6 qualifying samples out of 100. Its six modeled biome-admitted sources have **zero modeled wet-bank draws**. This negative result is preserved in `terrain-selection.json`; it is not silently substituted by the recommended candidate.

Across all 4,356 terrain samples: 610 have a wetland biome and 16 meet the complete habitat proxy. All samples are reported in `terrain-samples.jsonl`, including refusals. `waterEvaluated=false` explicitly identifies skipped water checks where the sample has no wetland solid-ground proxy; `waterAdjacent=false` in those rows is not a measured lack of water. All 841 window scores are retained in `all-window-scores.jsonl`.

## All source outcomes

The fixed 1,089 sources produce 164 rarity passes and 28 wetland origins. There are seven modeled wet-bank draws across six distinct candidate coordinates in four source chunks. These are all of them:

| Source chunk | Modeled origin | Wet-bank attempts | Distinct coordinates |
| --- | --- | --- | --- |
| (-109,-50) | (-1737,63,-786) | 9,13,23,24 | 3 |
| (-111,-39) | (-1768,64,-610) | 20: (-1766,63,-610) | 1 |
| (-108,-45) | (-1724,64,-715) | 14: (-1726,64,-718) | 1 |
| (-107,-46) | (-1710,63,-726) | 20: (-1707,63,-723) | 1 |

`all-random-outcomes.jsonl` has one record for every source, including all 925 rarity failures. `model-summary.json` reports complete accounting. All three rarity-admitted origins inside the recommended 3×3 are swamp: (-109,-50), (-108,-50), and (-108,-49). Only the first has modeled bank draws. The full source corpus is an upper bound before native nearby-biome scheduling; calling a rarity calculation here does not claim native scheduling happened.

## Native discovery requirements

1. Preserve the original seed, original biome-finder result (-1536,64,-768), and original 81-chunk zero case as a separate absence/regression case. Native receipt `../b3-wetland-native.log` establishes five calls, 120 attempts, 108 moisture rejections, 12 empty rejections, and no writes.
2. In a fresh world with the same normal Overworld settings and unchanged production resources, load exactly the recommended fixed 3×3. Generate naturally through ordinary chunk loading. Do not call a feature command, invoke `MoonreedFeature.place`, provide prepared terrain, replace blocks, alter density, or search beyond its bound on failure.
3. Observe source chunk (-109,-50) and its complete real placement chain. The passive observation halo for this 3×3 is X -111..-107, Z -52..-48; it must observe only normally generated sources, not load extra chunks just to collect receipts. Confirm actual stage/index and registry keys again.
4. Require a real successful `setBlock` receipt and a surviving naturally generated AGE=1 Moonreed at one of the observed writes. Check actual tagged support, no fluid at the plant, actual moisture and open sky. Use the original height detector plus an independent palette scan so missed detection can be distinguished from no generation.
5. Record every candidate rejection and write, including the duplicate draw. If native discovery fails, keep that result and do not relabel this a known-natural positive.
6. If the parent chooses to verify the whole finite model candidate cohort, fix all four 3×3 regions before launching, record all four outcomes, and do not extend the corpus on a zero. Their union contains 32 distinct chunks. This is a separately declared native discovery plan, not a replacement for the negative preregistered terrain-only result. A subsequently confirmed site may become a named deterministic positive fixture with that discovery provenance.

## Reproduction and validation

Run `python3 run-model.py`, then `python3 audit-results.py` in this directory. The scripts use Java25 and the cached original official 26.3 server jar and dependency jars, with explicit classpath. Their paths are in `classpath.txt`; the original dependency provenance is retained in `/workspace/shared/wildercord_compile_verification`.

The audit checks all sample/window/source counts and bounds, uniqueness, and the 24-draw rule. It also cross-checks the modeled original window against every existing native attempt receipt. **All 120 X/Z coordinates and heights match**, with no mismatches. This validates deterministic input reconstruction at the original window; it does not prove decorated state at the new sites. Ten terrain sample heights also match direct native `getBaseHeight` calls rather than the cached full noise-column top scan.

`source-manifest.json` hashes the inspected production/test inputs, preregistration, native receipt, official server jar, model source, and runner. `artifact-manifest.json` hashes the outputs. The only files written by this survey are under this directory.
