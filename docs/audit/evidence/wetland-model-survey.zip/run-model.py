#!/usr/bin/env python3
"""Run fixed, terrain-first native-library survey. No server launch or feature placement."""
from pathlib import Path
import subprocess,hashlib,json
here=Path(__file__).resolve().parent
root=Path('/workspace/shared/wildercord_compile_verification')
java=Path('/workspace/shared/toolchains/jdk-25.0.4.1+1/bin')
cp=':'.join(map(str,[root/'originals/minecraft-server-inner.jar',*sorted(root.glob('dependencies/**/*.jar'))]))
(here/'classpath.txt').write_text(cp+'\n')
subprocess.run([java/'javac','--release','25','-proc:none','-cp',cp,'-d',here,here/'WetlandPositiveSearch.java'],check=True)
with (here/'model-run.log').open('w') as out:
 subprocess.run([java/'java','-Xmx2G','-cp',str(here)+':'+cp,'WetlandPositiveSearch'],cwd=here,stdout=out,stderr=subprocess.STDOUT,check=True)
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(here.iterdir()) if p.is_file() and p.suffix in ('.java','.py','.json','.jsonl','.txt','.log') and p.name!='artifact-manifest.json'}
(here/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(here/'model-summary.json')
