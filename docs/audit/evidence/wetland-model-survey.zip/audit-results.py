#!/usr/bin/env python3
"""Audit fixed sampling bounds and cross-check modeled random coordinates against native receipts."""
from pathlib import Path
import json,re,hashlib
p=Path(__file__).resolve().parent
rows=lambda name:[json.loads(l) for l in (p/name).read_text().splitlines()]
terrain=rows('terrain-samples.jsonl');windows=rows('all-window-scores.jsonl');random=rows('all-random-outcomes.jsonl')
assert len(terrain)==4356 and len(windows)==841 and len(random)==1089
assert len({(s['x'],s['z']) for s in terrain})==4356
assert all(-112<=s['x']//16<=-80 and -64<=s['z']//16<=-32 and s['x']%16 in (4,12) and s['z']%16 in (4,12) for s in terrain)
assert len({tuple(r['chunk']) for r in random})==1089
assert all(len(r.get('attempts',[]))==24 if r['rarityPass'] else not r.get('attempts') for r in random)
by_chunk={tuple(r['chunk']):r for r in random}
log=Path('/workspace/shared/wildercord_recovery/ci/b3-wetland-native.log').read_text()
matched=0;height_differences=[]
for m in re.finditer(r'WETLAND_GENERATION ATTEMPT source=(-?\d+)/(-?\d+), scope=inside81, origin=(-?\d+)/(-?\d+)/(-?\d+), ordinal=(\d+), at=(-?\d+)/(-?\d+)/(-?\d+)',log):
 cx,cz,ox,oy,oz,n,x,y,z=map(int,m.groups());r=by_chunk[(cx,cz)];a=r['attempts'][n-1]['sample'];o=r['origin']
 assert r['originBiomeAllows'] and (o['x'],o['z'])==(ox,oz) and (a['x'],a['z'])==(x,z)
 matched+=1
 if a['y']!=y:height_differences.append({'source':[cx,cz],'attempt':n,'baseY':a['y'],'nativeY':y})
assert matched==120
candidates=[]
for r in random:
 if r.get('wetGroundProxyDraws',0):
  wet=[a for a in r['attempts'] if a.get('sample',{}).get('eligible')]
  candidates.append({'sourceChunk':r['chunk'],'origin':r['origin'],'wetDraws':wet,'uniqueWetCoordinates':len({(a['sample']['x'],a['sample']['y'],a['sample']['z']) for a in wet})})
candidates.sort(key=lambda r:(-r['uniqueWetCoordinates'],r['sourceChunk']))
(p/'native-discovery-candidates.json').write_text(json.dumps({'selectionPhase':'post-model fixed cohort; not the terrain-only preregistered winner','allModelPositiveSources':candidates,'recommendedFirstSource':candidates[0]['sourceChunk'],'nativeVerified':False},indent=2)+'\n')
report={'passed':True,'terrainSamples':len(terrain),'windowScores':len(windows),'sourceChunks':len(random),'nativeAttemptXZMatches':matched,'nativeBaseHeightDifferences':height_differences,'nativeReceiptSha256':hashlib.sha256(Path('/workspace/shared/wildercord_recovery/ci/b3-wetland-native.log').read_bytes()).hexdigest(),'allCandidateSources':len(candidates)}
(p/'audit-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
